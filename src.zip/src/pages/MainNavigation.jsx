import React from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import PageNotFound from './PageNotFound';
import Profile from '../components/Profile';
import Registration from './Registration/Registration';
import Login from './Login/Login';
import User from '../components/User'
import { useAuthContext } from '../Context/authContext';
import BookListing  from './book-listing/index.jsx';
import Book from './book/index.jsx';
import EditBook from './book/editBook/index.jsx';



const MainNavigation = () => {

    const name="Jyoti";

    const clickme = ()=> alert("alert");

    const authContext=useAuthContext();

    const Redirect=<Navigate to='/Login'/>

  return (
 
    <Routes>
        {/* <Route path='/User' element={<User name={name} fun={clickme} />}></Route> */}
          <Route exact path='/UpdateProfile' element={<Profile/>} />
          <Route exact path='/Registration' element={<Registration/>} />
          <Route exact path='/Login' element={<Login/>} />
          <Route exact path='/BookListing' element={authContext.user.id ? <BookListing/> : Redirect} />   
          <Route exact path='/Book' element={ <Book/> }/>
          <Route exact path='/EditBook' element={<EditBook/> }/> 
          <Route exact path='*' element={<PageNotFound/>} />
    </Routes>
  )
}

export default MainNavigation
