import React, { createContext, useEffect, useState } from 'react'
import { useContext } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import shared from '../shared'

const initialUserValue={
    id:0,
    email:'',
    firstName:'',
    lastName:'',
    roleId:0,
    role:" ",
    password:''

}


const initialState={
   setUser:()=>{},
   user:initialUserValue,
   signOut:()=>{},
//    appInitialize:false,
}
const authContext = createContext(initialState) ;

export const AuthWrapper=({children})=>{

    const [user,_setuser]=useState(initialUserValue)

    const LocalStorageKeys={
        USER:'user',
    }

    const setUser=(user)=>{
        localStorage.setItem(LocalStorageKeys.USER,JSON.stringify(user))
        _setuser(user)
    }
    const signOut=()=>{
        localStorage.removeItem(LocalStorageKeys.USER);
        _setuser(initialUserValue);
         navigate('/Login')
    }
   const navigate=useNavigate();
   const {pathname}=useLocation()

      useEffect(()=>{
        const str=JSON.parse(localStorage.getItem(LocalStorageKeys.USER)) || initialUserValue;
        if(str.id){
            _setuser(str);
        }
        if(!str.id){
        // navigate("/Login");
        }

      },[])

       useEffect(()=>{
        if(pathname === '/Login' && user.id){
           navigate('/Login');
        }
        if(!user.id){
          return ;
        }
        const access=shared.hasAccess(pathname,user);
        // if(!access){
        //   toast.warning("Sorry you are not authorized to access this page");
        //   navigate('/BookListing')
        //   return;
        // }

       },[pathname,user])

    const value={
      user,
      setUser,
      signOut
    }

    return <authContext.Provider value={value}>{children}</authContext.Provider>
}

export const useAuthContext=()=>{
  return useContext(authContext);
}

