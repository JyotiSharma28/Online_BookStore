import React from "react";

const  Profile=()=>{
    return(
       
        <div>
        <h1 style={{color:'red'}}>Profile Component </h1> 
        
           
        </div>
       

    );

};

export default Profile;