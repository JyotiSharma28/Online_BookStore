import React from 'react'

const PageNotFound = () => {
  return (
    <div>
        <h1 style={{color:'red',marginTop:'100px'}}>Page Not Found </h1> 
        
           
        </div>
  )
}

export default PageNotFound
